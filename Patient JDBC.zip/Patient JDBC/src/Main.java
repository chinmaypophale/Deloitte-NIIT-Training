import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import oracle.jdbc.driver.OracleDriver;

public class Main {

	Driver d = null;
	Connection conn = null;
	
	public void connect() {
		
		try {
			d = new OracleDriver();
			DriverManager.registerDriver(d);
			
			String uername = "hr";
			String password = "hr";
			String url = "jdbc:oracle:thin:@192.168.1.54:1521:xe";
			
			conn = DriverManager.getConnection(url, uername, password);
			//conn.setAutoCommit(false);
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("Connecting to oracle database");
	}
	
	
	public void insertElements(int id, String name, String email) {
		String query = "insert into PatientClinic values (?,?,?,?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			stmt.setInt(1, id);
			stmt.setString(2, name);
			stmt.setString(3, email);
			stmt.setDate(4, java.sql.Date.valueOf(java.time.LocalDate.now()));
			
			int r = stmt.executeUpdate();
			System.out.println(r + " row inserted in PatientClinic");
			} catch (SQLException e) {
			System.out.println("Error in inserting data in PatientClinic!");
			e.printStackTrace();
		}
	}
	
	public void insertElementsPrescription(int PPid, int Pid,String MedName) {
		String query = "insert into PatientPrescription values (?,?,?,?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			stmt.setInt(1, PPid);
			stmt.setDate(2,java.sql.Date.valueOf(java.time.LocalDate.now()) );
			stmt.setInt(3, Pid);
			stmt.setString(4,MedName);
			
			int r = stmt.executeUpdate();
			System.out.println(r + " row inserted in PatientPrescription");
			} catch (SQLException e) {
			System.out.println("Error in inserting data in PatientPrescription!");
			e.printStackTrace();
		}
	}
	
	
	public void update(int id,String str) {
		String query = "update PatientClinic set PatientEmail = (?) where PatientId = (?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			stmt.setString(1, str);
			stmt.setInt(2, id);
			
			int r = stmt.executeUpdate();
			System.out.println(r + " row updated!");
		} 
		catch (SQLException e) {
			System.out.println("Error in updating!!!");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void updatePrescription(int id,String str) {
		String query = "update PatientPrescription set MedicineName = (?) where PatientId = (?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			stmt.setString(1, str);
			stmt.setInt(2, id);
			
			int r = stmt.executeUpdate();
			System.out.println(r + " row updated!");
		} 
		catch (SQLException e) {
			System.out.println("Error in updating!!!");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void display() {
		String query = "select * from PatientClinic";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				System.out.print("ID := "+rs.getInt("PatientId"));
				System.out.println("  Name := "+ rs.getString("PatientName")+" "+rs.getString("PatientEmail")+rs.getDate("PatientRegDate"));
				
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void displayPrescription() {
		String query = "select * from PatientPrescription";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				System.out.print("ID := "+rs.getInt("PrescriptionId"));
				System.out.println("  Date := "+ rs.getDate("PrescribedDate")+" Patient Id  "+rs.getInt("PatientId")+ " Medicine Name "+rs.getString("MedicineName"));
				
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void delete(int id) {
		
		deletePrescription(id);
		
		String query = "delete from PatientClinic where PatientId = (?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			stmt.setInt(1, id);
			
			int r = stmt.executeUpdate();
			System.out.println(r+" row deleted!");
		} 
		catch (SQLException e) {
			System.out.println("Error in deleting!");
			e.printStackTrace();
		}
		
		
		
		
		System.out.println("Record Successfully Deleted from Patient Table and PatientPrescription Deleted");
		System.out.println("All the Foreign Key Constraints Satisfied");
	}
	
	public void deletePrescription(int id) {
		String query = "delete from PatientPrescription where PatientId = (?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(query);
			
			stmt.setInt(1, id);
			
			int r = stmt.executeUpdate();
			System.out.println(r+" row deleted!");
		} 
		catch (SQLException e) {
			System.out.println("Error in deleting!");
			e.printStackTrace();
		}
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Main obj = new Main();
		obj.connect();
//		Connection Done
		
		Scanner sc = new Scanner(System.in);
		int cont=1;
		while(cont==1) {
		int choice;
		
		System.out.println("Enter the Choice of Operation");
		System.out.println("1. Enter Data in PatientClinic Table");
		System.out.println("2.Enter Data in PatientPrescription Table");
		System.out.println("3.Display Contents From PatientClinic Table");
		System.out.println("4.Display Contents From PatientPrescription Table");
		
		System.out.println("5.Update Contents From PatientClinic Table");
		System.out.println("6.Update Contents From PatientPrescription Table");
		System.out.println("7.Delete Contents From PatientPrescription Table");
		System.out.println("8.Delete Contents From PatientClinic Table Satisfying ALl Constraints");
		
		choice = sc.nextInt();
		
		switch (choice) {
		case 1:
			int PatientId;
			String PatientName, PatientEmail;
			
			System.out.println("Enter Patient Id, Name and Email");
			PatientId = sc.nextInt();
			PatientName = sc.next();
			PatientEmail = sc.next();
			
			obj.insertElements(PatientId, PatientName, PatientEmail);
			obj.display();
			
			break;
		case 2:
			int PrescriptionId,PId;
			String MedicineName;
			
			System.out.println("Enter PrescriptionId, PatientId, MedicineName");
			PrescriptionId = sc.nextInt();
			PId = sc.nextInt();
			MedicineName = sc.next();
			
			obj.insertElementsPrescription(PrescriptionId, PId, MedicineName);
			obj.displayPrescription();
			
			
			
			break;
		case 3:
			
			obj.display();
			
			break;
		case 4:
			obj.displayPrescription();
			break;
		case 5:
			int pid;
			String name;
			
			System.out.println("Enter the Patient Id and  name to be updated ");
			pid=sc.nextInt();
			name=sc.next();
			
			obj.update(pid, name);
			obj.display();
			break;
		case 6:
			
			int Pid;
			String MedName;
			
			System.out.println("Enter the Patient Id and  Medcine Name to be updated ");
			Pid=sc.nextInt();
			MedName=sc.next();
			obj.updatePrescription(Pid, MedName);
			obj.displayPrescription();
			
			break;
		case 7:
			int piid;
			
				System.out.println("Enter the Patient Id whose records want to be deleted");
				piid = sc.nextInt();
				obj.deletePrescription(piid);
				obj.displayPrescription();
				
			
			break;
		case 8:
			int PID;
			
			System.out.println("Enter the PID whose record wants be deleted");
			PID = sc.nextInt();
			obj.delete(PID);
			obj.display();
			break;

		default:
			break;
		}
		
		System.out.println("Do You Want to Continue? yes = 1 and No = 0");
		cont=sc.nextInt();
		}
		
	}

}
