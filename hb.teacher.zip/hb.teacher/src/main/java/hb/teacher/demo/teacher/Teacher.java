package hb.teacher.demo.teacher;

import javax.persistence.Column;
import javax.persistence.Id;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Teacher")

public class Teacher {
	
	@Id 
	@Column(name = "ID")
	private int id;
	
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "SCHOOL")
	private String school;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public Teacher(int id, String name, String school) {
	
		this.id = id;
		this.name = name;
		this.school = school;
	}
	
	public Teacher() {
		
	}

	
}
