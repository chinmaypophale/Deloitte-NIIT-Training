package book.maven.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Books2")
public class Books {

	@Id
	@Column(name = "names")
	private String names;
	@Column(name = "author")
	private String author;

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Books(String names, String author) {
		this.names = names;
		this.author = author;
	}

	@Override
	public String toString() {
		return "Books [names=" + names + ", author=" + author + "]";
	}
	
	
	
}
