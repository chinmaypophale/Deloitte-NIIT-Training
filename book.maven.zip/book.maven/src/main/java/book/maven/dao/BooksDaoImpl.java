package book.maven.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import book.maven.model.Books;


@Repository
public class BooksDaoImpl implements BooksDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	public List<Books> findAll() {
		Session session = sessionFactory.getCurrentSession();
		return session.createQuery("from Books s",Books.class).getResultList();
	}

	public void create(Books s) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				Session session = sessionFactory.getCurrentSession();
				session.save(s);
		
	}
	
	@PostConstruct
	private void init() {
		System.out.println("Created the Obj");
	}
	
	@PreDestroy
	private void destroy() {
		System.out.println("Destroyed the Obj");
	}


}
