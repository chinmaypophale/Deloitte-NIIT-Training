package book.maven.dao;

import java.util.List;

import book.maven.model.Books;


public interface BooksDao {

public List<Books>findAll();
	
	public void create(Books s);
}
