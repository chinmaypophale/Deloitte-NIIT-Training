package book.maven.service;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import book.maven.dao.BooksDao;
import book.maven.model.Books;

@Service
public class BookServiceImpl implements BooksService {
	
	@Autowired
	private BooksDao booksDao;
	
	@PostConstruct
	private void init() {
		System.out.println("Created the Obj");
	}
	
	@PreDestroy
	private void destroy() {
		System.out.println("Destroyed the Obj");
	}

	@Transactional
	public List<Books> findAll() {
		// TODO Auto-generated method stub
		return booksDao.findAll();
	}

	@Transactional
	public void create(Books s) {
		// TODO Auto-generated method stub
		booksDao.create(s);
	}

}
