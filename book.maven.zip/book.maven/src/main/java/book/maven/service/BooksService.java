package book.maven.service;

import java.util.List;

import book.maven.model.Books;


public interface BooksService {
	
	public  List<Books>findAll();
	public void create(Books s);

}
