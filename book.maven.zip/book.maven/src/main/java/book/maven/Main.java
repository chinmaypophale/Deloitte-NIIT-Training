package book.maven;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import book.maven.config.AppConfig;
import book.maven.model.Books;
import book.maven.service.BooksService;


public class Main {

	public static void main(String[] args) {
		try {
			AnnotationConfigApplicationContext ctx = 
					new AnnotationConfigApplicationContext(AppConfig.class);
			
			BooksService service = ctx.getBean(BooksService.class);
			List<Books> s = service.findAll();
	
			for(Books book: s) {
				System.out.println(book);
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}