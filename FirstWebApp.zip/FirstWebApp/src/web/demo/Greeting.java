package web.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Greeting
 */


//Two Methods for web servlet
//@WebServlet("/greeting")
@WebServlet(urlPatterns = {"/greeting","/welcome"})
public class Greeting extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Greeting() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		//greeting the user
		
		String userName = request.getParameter("userName");
		int no1 = Integer.parseInt(request.getParameter("no1"));
		int no2 = Integer.parseInt(request.getParameter("no2"));
		
		System.out.println("UserName is "+userName);
		
//		Rendering Response to the User
		
//		Adding Header
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>"+"Welcome ".concat(userName)+"</h1>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>HelloPage</title>");
		out.println("<body>");
		out.println("<p>Hello People</p>"+userName +"  "+ no1 + no2+ "<br>");
		
		for (int i = 1; i <=no2 ; i++) {
			out.println(no1+"*"+i+"="+no1*i+"<br>");
			
		}
		out.println("</body>");
		out.println("</html>");
		
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
