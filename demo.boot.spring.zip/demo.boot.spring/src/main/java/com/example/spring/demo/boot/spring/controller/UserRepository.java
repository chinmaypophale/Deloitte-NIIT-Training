package com.example.spring.demo.boot.spring.controller;

import org.springframework.data.repository.CrudRepository;

import com.example.spring.demo.boot.spring.model.User;

public interface UserRepository  extends CrudRepository<User, Integer>{

}
