package er.hb.demo.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Batch")
public class Batch {

	@Id
	@Column(name="id")
	private int id;
	
	@ManyToOne
	private Trainer trainer;
	
	@OneToMany
	private List<Trainee>trainees;
	
	@OneToOne
	private Lab lab;
	
	@ManyToOne
	private Schedule schedule;
	
	@ManyToOne
	private Curriculum curriculum;
	
	public Batch() {
		// TODO Auto-generated constructor stub
	}

	public Batch(int id, Trainer trainer, List<Trainee> trainees, Lab lab, Schedule schedule, Curriculum curriculum) {
		super();
		this.id = id;
		this.trainer = trainer;
		this.trainees = trainees;
		this.lab = lab;
		this.schedule = schedule;
		this.curriculum = curriculum;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Trainer getTrainer() {
		return trainer;
	}

	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}

	public List<Trainee> getTrainees() {
		return trainees;
	}

	public void setTrainees(List<Trainee> trainees) {
		this.trainees = trainees;
	}

	public Lab getLab() {
		return lab;
	}

	public void setLab(Lab lab) {
		this.lab = lab;
	}

	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public Curriculum getCurriculum() {
		return curriculum;
	}

	public void setCurriculum(Curriculum curriculum) {
		this.curriculum = curriculum;
	}
	
	
}
