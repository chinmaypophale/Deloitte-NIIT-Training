package er.hb.demo.model;

import java.util.List;

public class Curriculum {
	
	private int id;
	
	private Trainer trainer;
	
	private List<String>topics;
	
	
	public Curriculum() {
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Trainer getTrainer() {
		return trainer;
	}


	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}


	public List<String> getTopics() {
		return topics;
	}


	public void setTopics(List<String> topics) {
		this.topics = topics;
	}


	public Curriculum(int id, Trainer trainer, List<String> topics) {
		super();
		this.id = id;
		this.trainer = trainer;
		this.topics = topics;
	}
	
	

}
