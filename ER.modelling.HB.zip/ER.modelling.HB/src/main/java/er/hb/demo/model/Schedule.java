package er.hb.demo.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Schedule {
	
	@Id
	private int id;
	
	private Date startDate;
	
	private Date endDate;
	
	
	private List<Batch>batches;
	
	
	public Schedule() {
		// TODO Auto-generated constructor stub
	}


	public Schedule(int id, Date startDate, Date endDate, List<Batch> batches) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.batches = batches;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	public List<Batch> getBatches() {
		return batches;
	}


	public void setBatches(List<Batch> batches) {
		this.batches = batches;
	}
	
	

}
