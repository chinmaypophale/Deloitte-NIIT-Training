package er.hb.demo.model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import er.hb.demo.model.Batch;

public class EntityDao {
	
	
	private static StandardServiceRegistry registry;
	private static SessionFactory sessionFactory;
	
	static Transaction transaction = null;

	public static void create(Batch batch) {
		
		try (Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			session.save(batch);
			session.getTransaction().commit();
		}
	}
	
	public static void create(Curriculum curriculum) {
		
		try (Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			session.save(curriculum);
			session.getTransaction().commit();
		}
	}

	public static void create(Lab lab) {
		
		try (Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			session.save(lab);
			session.getTransaction().commit();
		}
	}
	
	public static void create(Schedule schedule) {
		
		try (Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			session.save(schedule);
			session.getTransaction().commit();
		}
	}
	
	public static void create(Trainer trainer) {
		
		try (Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			session.save(trainer);
			session.getTransaction().commit();
		}
	}
	
	public static void create(Trainee trainee) {
		
		try (Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			session.save(trainee);
			session.getTransaction().commit();
		}
	}

	
	
	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
		}
		return sessionFactory;
	}

	public static void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}

}
