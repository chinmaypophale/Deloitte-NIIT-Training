package er.hb.demo;

import er.hb.demo.model.Batch;
import er.hb.demo.model.Curriculum;
import er.hb.demo.model.Lab;
import er.hb.demo.model.Schedule;
import er.hb.demo.model.Trainee;
import er.hb.demo.model.Trainer;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Batch batch = new Batch();
		
		Curriculum curriculum = new Curriculum();
		
		Lab lab = new Lab();
		
		Schedule schedule = new Schedule();
		
		Trainee trainee = new Trainee();
		
		Trainer trainer = new Trainer();
		
		

	}

}
