package demo.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.jdbc.driver.OracleDriver;

/**
 * Servlet implementation class DisplayServlet
 */
@WebServlet("/DisplayServlet")
public class DisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	
		
		String Name = request.getParameter("name");
		String Batch = request.getParameter("Batch");
		
		response.setContentType("text/html");
		
		
		try {
			Driver d = new OracleDriver();
			DriverManager.registerDriver(d);
			

			PrintWriter outPrintWriter = response.getWriter();
			
			

			
			String url = "jdbc:oracle:thin:@192.168.1.54:1521:xe";
			String userName = "hr";
			String password = "hr";
			Connection conn = DriverManager.getConnection(url,userName,password);
			System.out.println("Connection to Oracle Done Display Servlet");
			
			String query = "select * from StudentData";
			PreparedStatement pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			outPrintWriter.println("<form name='deleteForm' action='DisplayServlet' "
					+ "method='post'>");
			while (rs.next()) {
				outPrintWriter.println(rs.getString("names")
						+" "+rs.getString("batches")
						+"<button type='submit'>Delete</button><input type='hidden' name='delName' value='"+rs.getString("names")+"'/><br><br>");
			}
			outPrintWriter.println("</form>");
			
			
//			pstmt.setString(1, Name);
//			pstmt.setString(2, Batch);
//			int rows = pstmt.executeUpdate();
//			System.out.println(rows);
//		
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String Name = request.getParameter("delName");
		
		response.setContentType("text/html");
		
		
		try {
			Driver d = new OracleDriver();
			DriverManager.registerDriver(d);
			

			PrintWriter outPrintWriter = response.getWriter();
			
					
			String url = "jdbc:oracle:thin:@192.168.1.54:1521:xe";
			String userName = "hr";
			String password = "hr";
			Connection conn = DriverManager.getConnection(url,userName,password);
			System.out.println("Connection to Oracle Done Display Servlet");
			
			String queryDelete = "delete from StudentData where names=(?)";
			System.out.println(Name);
			PreparedStatement pstmt1 = conn.prepareStatement(queryDelete);
			pstmt1.setString(1, Name);
			int rows = pstmt1.executeUpdate();
			String query = "select * from StudentData";
			
			PreparedStatement pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				outPrintWriter.println("<form name='deleteForm' action='DisplayServlet' method='post'>");
				outPrintWriter.println(rs.getString("names")+" "+rs.getString("batches")
				+"<button type='submit' >Delete</button><input type='hidden' name='delName' value='"+rs.getString("names")+"'/>"
						+ "<br><br>");
				outPrintWriter.println("</form>");
			}
			
			
			
			
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
