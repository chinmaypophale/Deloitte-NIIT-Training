package com.demo.jpa.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.jpa.model.Note;
import com.demo.jpa.repository.NoteRepository;

@RestController
@RequestMapping("/api")
public class NoteController {
	
	@Autowired
	private NoteRepository noteRepository;
	
	@GetMapping("/notes")
	public List<Note> findAll(){
		return noteRepository.findAll();
	}
	
	@PostMapping("/notes")
	public Note saveNote(@Valid @RequestBody Note note) {
		note.setCreatedAt(new Date());
		note.setUpdatedAt(new Date());
		noteRepository.save(note);
		return note;
	}
	
	@GetMapping("/notes/{id}")
	public Optional<Note> getNoteById(@PathVariable (value = "id") Long noteId){
		return noteRepository.findById(noteId);
	}
	
	@PutMapping("/notes/{api}")
	public Note updateNote(@PathVariable(value = "id")Long id,@Valid @RequestBody Note n) {

		Optional<Note> note = noteRepository.findById(id);
		if (note.isPresent()) {
			note.get().setTitle(n.getTitle());
			note.get().setContent(n.getContent());
			n = noteRepository.save(note.get());
		}
		
		return n;
	}
	
	
	@DeleteMapping("/notes/{id}")
	public ResponseEntity<?> deleteNote(@PathVariable (value = "id") Long id){
		Optional<Note> note = noteRepository.findById(id);
		if (note.isPresent()) {
			noteRepository.delete(note.get());
		}
		return ResponseEntity.ok().build();
	}
	
	
}
