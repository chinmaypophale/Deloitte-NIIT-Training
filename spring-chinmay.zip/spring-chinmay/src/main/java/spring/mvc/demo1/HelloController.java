package spring.mvc.demo1;

import javax.xml.ws.RequestWrapper;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloController {

	@RequestMapping(path = {"/","/index"}, method=RequestMethod.GET)
	public String index(Model model,@RequestParam("no1")String no1,@RequestParam("no1")String no2) {
		model.addAttribute("no1",Integer.parseInt("25"));
		model.addAttribute("no2",Integer.parseInt("35"));
		model.addAttribute("sum",Integer.parseInt(no1)+Integer.parseInt(no2));
		return "index";
	}
}
