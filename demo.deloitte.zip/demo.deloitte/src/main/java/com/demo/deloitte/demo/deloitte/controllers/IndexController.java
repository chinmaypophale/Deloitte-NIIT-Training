package com.demo.deloitte.demo.deloitte.controllers;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.demo.deloitte.demo.deloitte.Student;

@Controller
public class IndexController {

	ArrayList<Student> ar = new ArrayList<>();

	@GetMapping("/hello/{name}")
	public String hello(@PathVariable String name, Model model) {
		model.addAttribute("user",name);
		return "hello" ;
	}
	
	@GetMapping("/add/thyme/{no1}/{no2}")
	public String addThyme(@PathVariable long no1, @PathVariable long no2,  Model model) {
		model.addAttribute("no1",no1);
		model.addAttribute("no2",no2);
		model.addAttribute("sum",no1+no2);
		return "add";
	}
	
	@GetMapping("/students/list")
	public String getStud(Model model) {
		
		Student student = new Student(12,"Chinmay");
		Student student2 = new Student(15, "R");
		
		ArrayList<Student> ar = new ArrayList<>();
		ar.add(student);
		ar.add(student2);
		
		model.addAttribute("users",ar);
			
		return "list";
	}
	
	
	
	@PostMapping("/users")
	public String addUser(Student user) {
		ar.add(user);
		return"redirect/list";
	}
	
	
	@GetMapping("/")
	public String index() {
		return "Hello World";
	}
	
	@GetMapping("/welcome/{name}")
	public String Welcome(@PathVariable String name) {
		return "Welcome"+name;
	}
	
	
	@GetMapping("/add/{num1}/{num2}")
	public long addMethod(@PathVariable long num1,@PathVariable long num2) {
		return (num1+num2);
	}
	
	@GetMapping("/sub/{num1}/{num2}")
	public long subMethod(@PathVariable(name= "num1") long no1,@PathVariable(name = "num2") long no2) {
		return (no1-no2);
	}
	
	@GetMapping("/string/compare/{str1}/{str2}")
	public String strCompare(@PathVariable(name = "str1") String str1, @PathVariable(name = "str2") String str2) {
		if(str1.equals(str2))
			return "Strings are Equal ";
		else 
			return "Strings are Un equal";
	}
	
	@GetMapping("/string/arrayList")
	public ArrayList<String> getList(){
		ArrayList<String> arr = new ArrayList<String>();
		arr.add("Chinmay");
		arr.add("Chinmay");
		arr.add("Chinmay");
		
		return arr;
	}
	
	@GetMapping("/classObject")
	public Student getObj() {
		Student s = new Student(12, "Chinmay");
		return s;
	}
	
	
	
}
