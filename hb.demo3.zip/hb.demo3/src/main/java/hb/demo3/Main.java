package hb.demo3;

import hb.demo3.model.HealthInsurance;
import hb.demo3.model.Insurance;
import hb.demo3.model.InsuranceDao;
import hb.demo3.model.TermInsurance;
import hb.demo3.model.VehicleInsurance;

public class Main {

	public static void main(String[] args) {

		HealthInsurance health = new HealthInsurance();
		TermInsurance term = new TermInsurance();
		VehicleInsurance vehicle = new VehicleInsurance();
		
		
		health.setId(1);
		health.setName("Chinmay");
		health.setSumInsured(2000);
		
		term.setId(2);
		term.setName("Raj");
		term.setSumInsured(300);
		term.setYears("5");
		
		vehicle.setId(3);
		vehicle.setName("Rohit");
		vehicle.setSumInsured(500);
		
		
		InsuranceDao insDao	= new InsuranceDao();
		
		Insurance obj = new Insurance();
		
		
		insDao.create(term);
		
		insDao.create(health);
		
		insDao.create(vehicle);
		
		insDao.shutdown();
		
		System.out.println("");
		
		
		
		
	}

}
