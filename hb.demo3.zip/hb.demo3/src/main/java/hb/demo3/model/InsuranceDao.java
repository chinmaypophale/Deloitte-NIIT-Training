package hb.demo3.model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.SharedSessionContract;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import hb.demo3.model.*;

public class InsuranceDao {
	
	private static StandardServiceRegistry registry;
	private static SessionFactory sessionFactory;
	
	static Transaction transaction = null;

	public static void create(Insurance obj) {
		
		try (Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			session.save(obj);
			session.getTransaction().commit();
		}
	}
	
	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
		}
		return sessionFactory;
	}

	public static void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}

}
