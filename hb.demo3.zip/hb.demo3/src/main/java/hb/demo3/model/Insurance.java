package hb.demo3.model;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

@MappedSuperclass
@Table(name = "insurance_details")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "ins_type",discriminatorType = DiscriminatorType.STRING)


public class Insurance {

	@Id
	@Column(name = "insured_id")
	private int id;
	
	@Column(name = "insured_amt")
	private int sumInsured;
	
	@Column(name = "insured_name")
	private String name;
	
	public Insurance() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(int sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
//	@Override
//	public toString() {
//		
//	}
	
	
}
