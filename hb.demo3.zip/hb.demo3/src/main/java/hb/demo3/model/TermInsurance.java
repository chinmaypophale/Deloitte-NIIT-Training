package hb.demo3.model;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "T_I")
public class TermInsurance extends Insurance{
	@Column(name = "insured_years")
	private String years;

	public TermInsurance() {
		
	}

	public String getYears() {
		return years;
	}

	public void setYears(String years) {
		this.years = years;
	}

	public TermInsurance(String years) {
	
		this.years = years;
	}
	
}
