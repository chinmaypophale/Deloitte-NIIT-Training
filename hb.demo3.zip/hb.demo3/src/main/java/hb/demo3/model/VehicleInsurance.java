package hb.demo3.model;


import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;



@Entity
@DiscriminatorValue(value = "V_I")
public class VehicleInsurance extends Insurance {

	@Column(name = "vehicle_type")
	private String vehicletype;

	public VehicleInsurance() {
		
	}
}
