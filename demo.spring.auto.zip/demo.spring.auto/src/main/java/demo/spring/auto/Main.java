package demo.spring.auto;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfigApplicationContext ctx = 
				new AnnotationConfigApplicationContext(AppConfig.class);
	
		
		DBDao dao = ctx.getBean(DBDao.class);
		
		try {
			dao.getAllStatements();
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}
