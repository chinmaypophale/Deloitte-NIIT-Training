package demo.spring.auto;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;

import oracle.jdbc.driver.OracleDriver;



public class DBDao {
	
	private String selectQuery = "select * from StudentData";
	
	@Autowired
	private Connection conn;
	
	public void getAllStatements() throws SQLException {
		PreparedStatement stmt = conn.prepareStatement(selectQuery);
		ResultSet rs = stmt.executeQuery();
		
		while (rs.next()) {
			System.out.println("name = "+rs.getString("Names")+"Batches "+rs.getString("Batches"));
		}
	}
	

}
