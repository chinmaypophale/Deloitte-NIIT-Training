package demo.spring.auto;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import oracle.jdbc.driver.OracleDriver;

@Configuration
@PropertySource("classpath:app.properties")
public class AppConfig {
	
	@Autowired
	private OracleDriver driver;
	
	
	@Value("${oracle.db.url}")
	private String url;
	
	@Value("${oracle.db.username}")
	private String userName;
	
	@Value("${oracle.db.password}")
	private String password;
	
	@PostConstruct
	private void printValues() {
		System.out.println("UserName:"+userName+"  Pass"+password+"  URL"+url);
	}
	
	@Bean
	public OracleDriver getOracleDriver() {
		return new OracleDriver();
	}
	
	@Bean
	public Connection getConnection()throws Exception{
		DriverManager.registerDriver(driver);
		return DriverManager.getConnection(url,userName,password);
	}
	
	@Bean
	public DBDao getDao() {
		return new DBDao();
	}

}
