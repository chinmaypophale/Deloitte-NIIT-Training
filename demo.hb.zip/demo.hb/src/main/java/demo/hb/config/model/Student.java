package demo.hb.config.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "StudentDataRec")
public class Student {

	@Override
	public String toString() {
		return "Student [names=" + names + ", Batches=" + Batches + "]";
	}

	@Id
	private String names;
	
	private String Batches;

	public String getNames() {
		return names;
	}
	
	public Student() {
		
	}

	public void setNames(String names) {
		this.names = names;
	}

	public String getBatches() {
		return Batches;
	}

	public void setBatches(String batches) {
		Batches = batches;
	}

	public Student(String names, String batches) {
		this.names = names;
		Batches = batches;
	}
	
	
}
