package demo.hb.config.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import demo.hb.config.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		
		Session session = sessionFactory.getCurrentSession();
		return session.createQuery("from Student s",Student.class).getResultList();
	}	

	@Override
	public void create(Student s) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		session.save(s);
	}
	
	@PostConstruct
	private void init() {
		System.out.println("Created the Obj");
	}
	
	@PreDestroy
	private void destroy() {
		System.out.println("Destroyed the Obj");
	}
	

}
