package demo.hb.config.service;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import demo.hb.config.dao.StudentDao;
import demo.hb.config.model.Student;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDao studentDao;
	

	@PostConstruct
	private void init() {
		System.out.println("Created the Obj");
	}
	
	@PreDestroy
	private void destroy() {
		System.out.println("Destroyed the Obj");
	}
	
	@Override
	@Transactional
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return studentDao.findAll();
	}

	@Override
	@Transactional
	public void create(Student s) {
		// TODO Auto-generated method stub
		studentDao.create(s);
	}

}
