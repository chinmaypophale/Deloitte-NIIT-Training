package web.demo;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import assessment.model.EntityDao;
import assessment.model.Medicine;
import assessment.model.Patient;
import assessment.model.Prescription;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		EntityDao entityDao = new EntityDao();
		
		Medicine medicine = new Medicine();
		Prescription prescription = new Prescription();
		
		 int PatientId = Integer.parseInt(request.getParameter("PatientId"));
		 response.getWriter().append("Id: "+PatientId);
		
		 String PatientName = request.getParameter("PatientName");
		 response.getWriter().append("Id: "+PatientName);
		
		 String PatientEmail = request.getParameter("PatientEmail");
		 response.getWriter().append("Id: "+PatientEmail);
		 
		 String PatientRegDate = request.getParameter("PatientRegDate");
		 response.getWriter().append("Id: "+PatientRegDate);
		 
		 int PrescriptionId = Integer.parseInt(request.getParameter("PrescriptionId")); 
		 String	PrescribedDate = request.getParameter("PrescribedDate"); 
		 String	Patient =  request.getParameter("Patient");
		 String	Medicines = request.getParameter("Medicines");

		 int MedicineId  = Integer.parseInt(request.getParameter("MedicineId"));
		 String	MedicineName = request.getParameter("Medicines"); 
		 
		 Patient patient = new Patient(PatientId,PatientName,PatientEmail,PatientRegDate);
		
		 Medicine medicine2 = new Medicine(MedicineId,MedicineName);
		 
		 Prescription prescription2 = new Prescription(PrescriptionId,PrescribedDate,Patient,Medicines);
		 
		 entityDao.create(patient);
		 entityDao.createMedicine(medicine2);
		 entityDao.createPrescription(prescription2);
		 entityDao.shutdown();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
