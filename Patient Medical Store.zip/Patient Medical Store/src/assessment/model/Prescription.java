package assessment.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PrescriptionMedStore2")
public class Prescription {
	
	
	@Column(name = "PrescriptionId")
	private int PrescriptionId;
	
	@Column(name = "PrescribedDate")
	private String PrescribedDate;
	
	@Column(name = "Patient")
	private String Patient;
	
	@Column(name = "MedicineList")
	private String MedicineList;
	
	
	@ManyToOne
	private Patient patient;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "Prescription_id")
	private List<Medicine> medicines;
	
	
	public Prescription() {
		// TODO Auto-generated constructor stub
	}
	
	

	public List<Medicine> getMedicines() {
		return medicines;
	}

	public void setMedicines(List<Medicine> medicines) {
		this.medicines = medicines;
	}
	
	

	public int getPrescriptionId() {
		return PrescriptionId;
	}

	public void setPrescriptionId(int prescriptionId) {
		PrescriptionId = prescriptionId;
	}

	public String getPrescribedDate() {
		return PrescribedDate;
	}

	public void setPrescribedDate(String prescribedDate) {
		PrescribedDate = prescribedDate;
	}

	public String getPatient() {
		return Patient;
	}

	public void setPatient(String patient) {
		Patient = patient;
	}

	public String getMedicineList() {
		return MedicineList;
	}

	public void setMedicineList(String medicineList) {
		MedicineList = medicineList;
	}

	/**
	 * @param prescriptionId
	 * @param prescribedDate
	 * @param patient
	 * @param medicineList
	 */
	public Prescription(int prescriptionId, String prescribedDate, String patient, String medicineList) {
		PrescriptionId = prescriptionId;
		PrescribedDate = prescribedDate;
		Patient = patient;
		MedicineList = medicineList;
	}
	
	
	
}
