package assessment.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "MedicineMedStore2")
public class Medicine {
	
	@Id
	@Column(name = "MedicineId")
	private int MedicineId;
	
	@Column(name = "MedicineName")
	private String MedicineName;
	
	@ManyToMany
	private List<Prescription> prescriptions;
	
	
	public List<Prescription> getPrescriptions() {
		return prescriptions;
	}

	public void setPrescriptions(List<Prescription> prescriptions) {
		this.prescriptions = prescriptions;
	}

	public int getMedicineId() {
		return MedicineId;
	}

	public void setMedicineId(int medicineId) {
		MedicineId = medicineId;
	}

	public String getMedicineName() {
		return MedicineName;
	}

	public void setMedicineName(String medicineName) {
		MedicineName = medicineName;
	}

	public Medicine(int medicineId, String medicineName) {
		MedicineId = medicineId;
		MedicineName = medicineName;
	}
	
	
	
	@Override
	public String toString() {
		return "Medicine [MedicineId=" + MedicineId + ", MedicineName=" + MedicineName + "]";
	}

	public Medicine() {
		// TODO Auto-generated constructor stub
	}
	
	
	

}
