package assessment.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="PatientMedStore2")
public class Patient {
	
	@Id
	@Column(name = "PatientId")
	private int PatientId;
	
	@Column(name = "PatientName")
	private String PatientName;
	
	@Column(name = "PatientEmail")
	private String PatientEmail;
	
	@Column(name = "PatientRegDate")
	private String PatientRegDate;
	

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "Patient_id")
	private List<Prescription> prescriptions;
	
	
	
	public int getPatientId() {
		return PatientId;
	}

	public void setPatientId(int patientId) {
		PatientId = patientId;
	}

	public String getPatientName() {
		return PatientName;
	}

	public void setPatientName(String patientName) {
		PatientName = patientName;
	}

	public String getPatientEmail() {
		return PatientEmail;
	}

	public void setPatientEmail(String patientEmail) {
		PatientEmail = patientEmail;
	}

	public String getPatientRegDate() {
		return PatientRegDate;
	}

	public void setPatientRegDate(String patientRegDate) {
		PatientRegDate = patientRegDate;
	}

	public Patient() {
		// TODO Auto-generated constructor stub
	}

	public Patient(int patientId, String patientName, String patientEmail, String patientRegDate) {
		PatientId = patientId;
		PatientName = patientName;
		PatientEmail = patientEmail;
		PatientRegDate = patientRegDate;
	}

	@Override
	public String toString() {
		return "Patient [PatientId=" + PatientId + ", PatientName=" + PatientName + ", PatientEmail=" + PatientEmail
				+ ", PatientRegDate=" + PatientRegDate + "]";
	}
	
	public List<Prescription> getPrescriptions() {
		return prescriptions;
	}

	public void setPrescriptions(List<Prescription> prescriptions) {
		this.prescriptions = prescriptions;
	}
	
	
	
	

//	public Patient(int patientId, String patientName, String patientEmail, String patientRegDate,
//			List<Prescription> prescriptions) {
//		PatientId = patientId;
//		PatientName = patientName;
//		PatientEmail = patientEmail;
//		PatientRegDate = patientRegDate;
//		this.prescriptions = prescriptions;
//	}
//	
//	
	
	
	
	
	

}
